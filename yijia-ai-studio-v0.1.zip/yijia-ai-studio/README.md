# 億家 AI Studio v0.1

第一版 AI 影片製作工作室 MVP。

## 已完成
- AI 影片工作室介面
- AI 腳本／分鏡 Demo Provider
- 9:16、16:9、1:1 比例
- 場景新增／刪除／編輯
- 上傳場景圖片
- 旁白、字幕、畫面提示詞、運鏡、秒數
- 瀏覽器中文語音預覽
- 時間軸預覽
- localStorage 自動儲存
- JSON 專案匯出
- 外部 AI API Provider 預留
- Supabase 環境變數預留

## 執行
1. 安裝 Node.js
2. 在專案資料夾開啟終端機
3. 執行：
   npm install
4. 再執行：
   npm run dev
5. 開啟終端機顯示的網址

## AI API
複製 `.env.example` 為 `.env`，設定：
VITE_AI_API_BASE=
VITE_AI_API_KEY=

若未設定，系統會使用內建 Demo Provider，因此仍可完整測試介面流程。

## 下一階段
- Supabase 登入／雲端專案
- 真正 AI 圖片生成
- 圖片轉影片 API
- AI TTS 配音
- 音樂軌
- 字幕時間碼
- FFmpeg / ffmpeg.wasm MP4 合成
- 專案素材庫
