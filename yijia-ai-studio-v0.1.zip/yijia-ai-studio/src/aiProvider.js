const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

const makeScenes = (topic, ratio) => {
  const cleaned = topic.trim() || '橘貓店長打開億家超商，準備開始一天的營業'
  const chunks = cleaned
    .split(/[，。！？,.!?]/)
    .map(v => v.trim())
    .filter(Boolean)

  const seeds = chunks.length ? chunks : [cleaned]
  return Array.from({ length: Math.min(Math.max(seeds.length, 4), 8) }, (_, i) => {
    const source = seeds[i % seeds.length]
    return {
      id: crypto.randomUUID(),
      title: `場景 ${i + 1}`,
      duration: 4,
      narration: source,
      visualPrompt: `${source}，電影感構圖，柔和光線，乾淨細節，適合 ${ratio} 短影音`,
      motion: i % 3 === 0 ? '慢慢推近' : i % 3 === 1 ? '輕微橫移' : '固定鏡位＋角色動作',
      subtitle: source,
      image: null,
    }
  })
}

export async function generateStoryboard({ topic, ratio }) {
  const apiBase = import.meta.env.VITE_AI_API_BASE
  const apiKey = import.meta.env.VITE_AI_API_KEY

  if (apiBase && apiKey) {
    const response = await fetch(`${apiBase.replace(/\/$/, '')}/storyboard`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ topic, ratio }),
    })
    if (!response.ok) throw new Error(`AI API 錯誤：${response.status}`)
    return response.json()
  }

  await sleep(650)
  return {
    title: topic.trim().slice(0, 30) || '未命名影片',
    scenes: makeScenes(topic, ratio),
    provider: 'demo',
  }
}
