const KEY = 'yijia-ai-studio-projects-v1'

export function loadProjects() {
  try {
    return JSON.parse(localStorage.getItem(KEY) || '[]')
  } catch {
    return []
  }
}

export function saveProjects(projects) {
  localStorage.setItem(KEY, JSON.stringify(projects))
}

export function downloadJson(project) {
  const blob = new Blob([JSON.stringify(project, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${project.name || 'yijia-ai-project'}.json`
  a.click()
  URL.revokeObjectURL(url)
}
