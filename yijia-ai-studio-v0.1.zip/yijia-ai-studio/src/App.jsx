import React, { useEffect, useMemo, useState } from 'react'
import {
  Bot, Captions, Download, FileVideo2, ImagePlus, Mic2, Music2,
  Pause, Play, Plus, Save, Scissors, Sparkles, Trash2, WandSparkles
} from 'lucide-react'
import { generateStoryboard } from './aiProvider'
import { downloadJson, loadProjects, saveProjects } from './storage'

const menu = [
  ['AI 影片', FileVideo2],
  ['AI 圖片', ImagePlus],
  ['AI 腳本', WandSparkles],
  ['AI 配音', Mic2],
  ['AI 字幕', Captions],
  ['音樂', Music2],
  ['剪輯', Scissors],
]

const initialProject = () => ({
  id: crypto.randomUUID(),
  name: '我的第一支 AI 影片',
  topic: '',
  ratio: '9:16',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  scenes: [],
})

export default function App() {
  const [projects, setProjects] = useState(() => loadProjects())
  const [project, setProject] = useState(() => loadProjects()[0] || initialProject())
  const [active, setActive] = useState('AI 影片')
  const [busy, setBusy] = useState(false)
  const [speaking, setSpeaking] = useState(false)

  useEffect(() => {
    const next = [project, ...projects.filter(p => p.id !== project.id)]
    setProjects(next)
    saveProjects(next)
  }, [project])

  const totalDuration = useMemo(
    () => project.scenes.reduce((sum, s) => sum + Number(s.duration || 0), 0),
    [project.scenes]
  )

  const updateProject = (patch) =>
    setProject(p => ({ ...p, ...patch, updatedAt: new Date().toISOString() }))

  const generate = async () => {
    if (!project.topic.trim()) return
    setBusy(true)
    try {
      const result = await generateStoryboard({ topic: project.topic, ratio: project.ratio })
      updateProject({ name: result.title || project.name, scenes: result.scenes || [] })
    } catch (err) {
      alert(err.message || '產生失敗')
    } finally {
      setBusy(false)
    }
  }

  const updateScene = (id, patch) => {
    updateProject({
      scenes: project.scenes.map(scene => scene.id === id ? { ...scene, ...patch } : scene)
    })
  }

  const deleteScene = id =>
    updateProject({ scenes: project.scenes.filter(scene => scene.id !== id) })

  const addScene = () => updateProject({
    scenes: [...project.scenes, {
      id: crypto.randomUUID(),
      title: `場景 ${project.scenes.length + 1}`,
      duration: 4,
      narration: '',
      visualPrompt: '',
      motion: '固定鏡位',
      subtitle: '',
      image: null
    }]
  })

  const speak = () => {
    if (!('speechSynthesis' in window)) return alert('這個瀏覽器不支援語音預覽')
    window.speechSynthesis.cancel()
    if (speaking) {
      setSpeaking(false)
      return
    }
    const text = project.scenes.map(s => s.narration).filter(Boolean).join('。')
    if (!text) return alert('目前沒有旁白內容')
    const utter = new SpeechSynthesisUtterance(text)
    utter.lang = 'zh-TW'
    utter.rate = 0.95
    utter.onend = () => setSpeaking(false)
    setSpeaking(true)
    window.speechSynthesis.speak(utter)
  }

  const importImage = (sceneId, file) => {
    if (!file) return
    const reader = new FileReader()
    reader.onload = e => updateScene(sceneId, { image: e.target.result })
    reader.readAsDataURL(file)
  }

  return (
    <div className="appShell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brandMark">億</div>
          <div><strong>億家 AI Studio</strong><small>AI Video Workspace</small></div>
        </div>
        <button className="newBtn" onClick={() => setProject(initialProject())}><Plus size={18}/>新增專案</button>
        <nav>
          {menu.map(([label, Icon]) => (
            <button key={label} className={active === label ? 'navItem active' : 'navItem'} onClick={() => setActive(label)}>
              <Icon size={18}/><span>{label}</span>
            </button>
          ))}
        </nav>
        <div className="sideFooter">
          <span>v0.1 MVP</span>
          <span>本機自動儲存</span>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <input className="projectName" value={project.name} onChange={e => updateProject({name:e.target.value})}/>
            <div className="muted">共 {project.scenes.length} 個場景 · 約 {totalDuration} 秒</div>
          </div>
          <div className="topActions">
            <button onClick={() => downloadJson(project)}><Download size={17}/>匯出專案</button>
            <button className="primary" onClick={() => { saveProjects([project, ...projects.filter(p=>p.id!==project.id)]); alert('已儲存') }}>
              <Save size={17}/>儲存
            </button>
          </div>
        </header>

        <section className="heroPanel">
          <div className="heroIcon"><Sparkles size={28}/></div>
          <div className="heroCopy">
            <h1>一句話，開始製作你的 AI 影片</h1>
            <p>輸入故事或主題，系統會先產生腳本、分鏡、字幕與畫面提示詞。</p>
            <textarea
              value={project.topic}
              onChange={e => updateProject({topic:e.target.value})}
              placeholder="例如：橘貓店長早上打開億家超商，整理貨架，熊貓店員跑進來上班……"
            />
            <div className="generatorBar">
              <select value={project.ratio} onChange={e => updateProject({ratio:e.target.value})}>
                <option>9:16</option><option>16:9</option><option>1:1</option>
              </select>
              <button className="primary big" onClick={generate} disabled={busy || !project.topic.trim()}>
                <Bot size={18}/>{busy ? 'AI 正在產生…' : '產生腳本與分鏡'}
              </button>
            </div>
          </div>
        </section>

        <section className="workspaceHeader">
          <div><h2>分鏡工作區</h2><p>每一張卡片就是影片中的一個場景。</p></div>
          <div className="row">
            <button onClick={speak}>{speaking ? <Pause size={17}/> : <Play size={17}/>}旁白預覽</button>
            <button onClick={addScene}><Plus size={17}/>新增場景</button>
          </div>
        </section>

        {project.scenes.length === 0 ? (
          <section className="empty">
            <FileVideo2 size={42}/><h3>還沒有分鏡</h3>
            <p>先在上方輸入故事，或手動新增第一個場景。</p>
            <button onClick={addScene}><Plus size={17}/>新增場景</button>
          </section>
        ) : (
          <section className="sceneGrid">
            {project.scenes.map((scene, index) => (
              <article className="sceneCard" key={scene.id}>
                <div className="scenePreview">
                  {scene.image ? <img src={scene.image} alt="" /> : <div><ImagePlus size={28}/><span>場景圖片</span></div>}
                  <span className="sceneIndex">{index + 1}</span>
                  <label className="imageButton">
                    上傳圖片
                    <input hidden type="file" accept="image/*" onChange={e => importImage(scene.id, e.target.files?.[0])}/>
                  </label>
                </div>
                <div className="sceneBody">
                  <div className="sceneTitleRow">
                    <input value={scene.title} onChange={e => updateScene(scene.id,{title:e.target.value})}/>
                    <button className="iconBtn danger" onClick={() => deleteScene(scene.id)}><Trash2 size={16}/></button>
                  </div>
                  <label>旁白<textarea value={scene.narration} onChange={e => updateScene(scene.id,{narration:e.target.value})}/></label>
                  <label>畫面提示詞<textarea value={scene.visualPrompt} onChange={e => updateScene(scene.id,{visualPrompt:e.target.value})}/></label>
                  <div className="twoCol">
                    <label>運鏡<input value={scene.motion} onChange={e => updateScene(scene.id,{motion:e.target.value})}/></label>
                    <label>秒數<input type="number" min="1" max="60" value={scene.duration} onChange={e => updateScene(scene.id,{duration:e.target.value})}/></label>
                  </div>
                  <label>字幕<textarea value={scene.subtitle} onChange={e => updateScene(scene.id,{subtitle:e.target.value})}/></label>
                </div>
              </article>
            ))}
          </section>
        )}

        <section className="timelinePanel">
          <div className="timelineTitle"><Scissors size={18}/>時間軸預覽</div>
          <div className="timeline">
            {project.scenes.map((s,i) => (
              <div key={s.id} className="clip" style={{flexGrow: Math.max(Number(s.duration)||1,1)}}>
                <strong>{i+1}</strong><span>{s.duration}s</span>
              </div>
            ))}
            {!project.scenes.length && <span className="muted">新增場景後會顯示時間軸。</span>}
          </div>
        </section>

        <section className="exportPanel">
          <div><h2>影片輸出</h2><p>v0.1 已完成專案資料、圖片、字幕、旁白與時間軸骨架；MP4 合成會在下一階段接 FFmpeg。</p></div>
          <button disabled><FileVideo2 size={18}/>MP4 匯出（下一階段）</button>
        </section>
      </main>
    </div>
  )
}
